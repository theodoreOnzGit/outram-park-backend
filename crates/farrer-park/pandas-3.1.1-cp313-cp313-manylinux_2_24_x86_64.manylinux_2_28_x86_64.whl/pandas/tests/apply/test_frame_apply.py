from datetime import datetime
import warnings

import numpy as np
import pytest

from pandas.compat import is_platform_arm

from pandas.core.dtypes.dtypes import CategoricalDtype

import pandas as pd
import pandas._testing as tm
from pandas.tests.apply.conftest import MockEngineDecorator
from pandas.tests.frame.common import zip_frames
from pandas.util.version import Version


@pytest.fixture
def int_frame_const_col():
    """
    Fixture for DataFrame of ints which are constant per column

    Columns are ['A', 'B', 'C'], with values (per column): [1, 2, 3]
    """
    df = pd.DataFrame(
        np.tile(np.arange(3, dtype="int64"), 6).reshape(6, -1) + 1,
        columns=["A", "B", "C"],
    )
    return df


@pytest.fixture(
    params=[
        "python",
        pytest.param("numba", marks=pytest.mark.single_cpu),
        MockEngineDecorator,
    ]
)
def engine(request):
    if request.param == "numba":
        pytest.importorskip("numba")
    return request.param


def test_apply(float_frame, engine, request):
    if engine == "numba":
        mark = pytest.mark.xfail(reason="numba engine not supporting numpy ufunc yet")
        request.node.add_marker(mark)
    with np.errstate(all="ignore"):
        # ufunc
        result = np.sqrt(float_frame["A"])
        expected = float_frame.apply(np.sqrt, engine=engine)["A"]
        tm.assert_series_equal(result, expected)

        # aggregator
        result = float_frame.apply(np.mean, engine=engine)["A"]
        expected = np.mean(float_frame["A"])
        assert result == expected

        d = float_frame.index[0]
        result = float_frame.apply(np.mean, axis=1, engine=engine)
        expected = np.mean(float_frame.xs(d))
        assert result[d] == expected
        assert result.index is float_frame.index


@pytest.mark.parametrize("axis", [0, 1])
@pytest.mark.parametrize("raw", [True, False])
def test_apply_args(float_frame, axis, raw, engine):
    numba = pytest.importorskip("numba")
    if (
        engine == "numba"
        and Version(numba.__version__) == Version("0.61")
        and is_platform_arm()
    ):
        pytest.skip(f"Segfaults on ARM platforms with numba {numba.__version__}")
    result = float_frame.apply(
        lambda x, y: x + y,
        axis,
        args=(1,),
        raw=raw,
        engine=engine,
    )
    expected = float_frame + 1
    tm.assert_frame_equal(result, expected)

    # GH:58712
    result = float_frame.apply(
        lambda x, a, b: x + a + b,
        args=(1,),
        b=2,
        raw=raw,
        engine=engine,
    )
    expected = float_frame + 3
    tm.assert_frame_equal(result, expected)

    if engine == "numba":
        # py signature binding
        with pytest.raises(TypeError, match="missing a required argument: 'a'"):
            float_frame.apply(
                lambda x, a: x + a,
                b=2,
                raw=raw,
                engine=engine,
            )

        # keyword-only arguments are not supported in numba
        with pytest.raises(
            pd.errors.NumbaUtilError,
            match="numba does not support keyword-only arguments",
        ):
            float_frame.apply(
                lambda x, a, *, b: x + a + b,
                args=(1,),
                b=2,
                raw=raw,
                engine=engine,
            )

        with pytest.raises(
            pd.errors.NumbaUtilError,
            match="numba does not support keyword-only arguments",
        ):
            float_frame.apply(
                lambda *x, b: x[0] + x[1] + b,
                args=(1,),
                b=2,
                raw=raw,
                engine=engine,
            )


def test_apply_categorical_func():
    # GH 9573
    df = pd.DataFrame({"c0": ["A", "A", "B", "B"], "c1": ["C", "C", "D", "D"]})
    result = df.apply(lambda ts: ts.astype("category"))

    assert result.shape == (4, 2)
    assert isinstance(result["c0"].dtype, CategoricalDtype)
    assert isinstance(result["c1"].dtype, CategoricalDtype)


def test_apply_axis1_with_ea():
    # GH#36785
    expected = pd.DataFrame({"A": [pd.Timestamp("2013-01-01", tz="UTC")]})
    result = expected.apply(lambda x: x, axis=1)
    tm.assert_frame_equal(result, expected)


def test_apply_axis1_ea_preserves_dtype():
    # GH#61747 - row dtype should match the interleaved dtype, not object
    df = pd.DataFrame(
        {
            "a": pd.array([1, 2, 3], dtype="Int64"),
            "b": pd.array([4, 5, 6], dtype="Int64"),
        }
    )
    result = df.apply(lambda row: row.dtype, axis=1)
    expected = pd.Series([pd.Int64Dtype()] * 3)
    tm.assert_series_equal(result, expected)


def test_apply_axis1_arrow_heterogeneous_dtypes():
    # GH#65097 - columns of differing pyarrow types must not raise; each row
    # is built as the upcast common dtype rather than the first column's type
    pa = pytest.importorskip("pyarrow")
    df = pd.DataFrame(
        {
            "a": pd.array([1, 2, 3], dtype="int64[pyarrow]"),
            "b": pd.array([1.5, 2.5, 3.5], dtype="float64[pyarrow]"),
        }
    )
    row_dtypes = df.apply(lambda row: row.dtype, axis=1)
    tm.assert_series_equal(row_dtypes, pd.Series([pd.ArrowDtype(pa.float64())] * 3))

    result = df.apply(lambda x: x.sum(), axis=1)
    expected = pd.Series([2.5, 4.5, 6.5])
    tm.assert_series_equal(result, expected)


def test_apply_axis1_masked_heterogeneous_dtypes():
    # GH#65097 - Int64 + Float64 columns build each row as the upcast Float64
    df = pd.DataFrame(
        {
            "a": pd.array([1, 2, 3], dtype="Int64"),
            "b": pd.array([1.5, 2.5, 3.5], dtype="Float64"),
        }
    )
    row_dtypes = df.apply(lambda row: row.dtype, axis=1)
    tm.assert_series_equal(row_dtypes, pd.Series([pd.Float64Dtype()] * 3))

    result = df.apply(lambda x: x.sum(), axis=1)
    expected = pd.Series([2.5, 4.5, 6.5])
    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize(
    "data, dtype",
    [
        (1, None),
        (1, CategoricalDtype([1])),
        (pd.Timestamp("2013-01-01", tz="UTC"), None),
    ],
)
def test_agg_axis1_duplicate_index(data, dtype):
    # GH 42380
    expected = pd.DataFrame([[data], [data]], index=["a", "a"], dtype=dtype)
    result = expected.agg(lambda x: x, axis=1)
    tm.assert_frame_equal(result, expected)


def test_apply_mixed_datetimelike():
    # mixed datetimelike
    # GH 7778
    expected = pd.DataFrame(
        {
            "A": pd.date_range("20130101", periods=3),
            "B": pd.to_timedelta(np.arange(3), unit="s"),
        }
    )
    result = expected.apply(lambda x: x, axis=1)
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize("func", [np.sqrt, np.mean])
def test_apply_empty(func, engine):
    # empty
    empty_frame = pd.DataFrame()

    result = empty_frame.apply(func, engine=engine)
    assert result.empty


def test_apply_float_frame(float_frame, engine):
    no_rows = float_frame[:0]
    result = no_rows.apply(lambda x: x.mean(), engine=engine)
    expected = pd.Series(np.nan, index=float_frame.columns)
    tm.assert_series_equal(result, expected)

    no_cols = float_frame.loc[:, []]
    result = no_cols.apply(lambda x: x.mean(), axis=1, engine=engine)
    expected = pd.Series(np.nan, index=float_frame.index)
    tm.assert_series_equal(result, expected)


def test_apply_empty_except_index(engine):
    # GH 2476
    expected = pd.DataFrame(index=["a"])
    result = expected.apply(lambda x: x["a"], axis=1, engine=engine)
    tm.assert_frame_equal(result, expected)


def test_apply_with_reduce_empty():
    # reduce with an empty DataFrame
    empty_frame = pd.DataFrame()

    x = []
    result = empty_frame.apply(x.append, axis=1, result_type="expand")
    tm.assert_frame_equal(result, empty_frame)
    result = empty_frame.apply(x.append, axis=1, result_type="reduce")
    expected = pd.Series([], dtype=np.float64)
    tm.assert_series_equal(result, expected)

    empty_with_cols = pd.DataFrame(columns=["a", "b", "c"])
    result = empty_with_cols.apply(x.append, axis=1, result_type="expand")
    tm.assert_frame_equal(result, empty_with_cols)
    result = empty_with_cols.apply(x.append, axis=1, result_type="reduce")
    expected = pd.Series([], dtype=np.float64)
    tm.assert_series_equal(result, expected)

    # Ensure that x.append hasn't been called
    assert x == []


@pytest.mark.parametrize("func", ["sum", "prod", "any", "all"])
def test_apply_funcs_over_empty(func):
    # GH 28213
    df = pd.DataFrame(columns=["a", "b", "c"])

    result = df.apply(getattr(np, func))
    expected = getattr(df, func)()
    if func in ("sum", "prod"):
        expected = expected.astype(float)
    tm.assert_series_equal(result, expected)


def test_nunique_empty():
    # GH 28213
    df = pd.DataFrame(columns=["a", "b", "c"])

    result = df.nunique()
    expected = pd.Series(0, index=df.columns)
    tm.assert_series_equal(result, expected)

    result = df.T.nunique()
    expected = pd.Series([], dtype=np.float64)
    tm.assert_series_equal(result, expected)


def test_apply_standard_nonunique():
    df = pd.DataFrame([[1, 2, 3], [4, 5, 6], [7, 8, 9]], index=["a", "a", "c"])

    result = df.apply(lambda s: s[0], axis=1)
    expected = pd.Series([1, 4, 7], ["a", "a", "c"])
    tm.assert_series_equal(result, expected)

    result = df.T.apply(lambda s: s[0], axis=0)
    tm.assert_series_equal(result, expected)


def test_apply_broadcast_scalars(float_frame):
    # scalars
    result = float_frame.apply(np.mean, result_type="broadcast")
    expected = pd.DataFrame([float_frame.mean()], index=float_frame.index)
    tm.assert_frame_equal(result, expected)


def test_apply_broadcast_scalars_axis1(float_frame):
    result = float_frame.apply(np.mean, axis=1, result_type="broadcast")
    m = float_frame.mean(axis=1)
    expected = pd.DataFrame(dict.fromkeys(float_frame.columns, m))
    tm.assert_frame_equal(result, expected)


def test_apply_broadcast_lists_columns(float_frame):
    # lists
    result = float_frame.apply(
        lambda x: list(range(len(float_frame.columns))),
        axis=1,
        result_type="broadcast",
    )
    m = list(range(len(float_frame.columns)))
    expected = pd.DataFrame(
        [m] * len(float_frame.index),
        dtype="float64",
        index=float_frame.index,
        columns=float_frame.columns,
    )
    tm.assert_frame_equal(result, expected)


def test_apply_broadcast_lists_index(float_frame):
    result = float_frame.apply(
        lambda x: list(range(len(float_frame.index))), result_type="broadcast"
    )
    m = list(range(len(float_frame.index)))
    expected = pd.DataFrame(
        dict.fromkeys(float_frame.columns, m),
        dtype="float64",
        index=float_frame.index,
    )
    tm.assert_frame_equal(result, expected)


def test_apply_broadcast_list_lambda_func(int_frame_const_col):
    # preserve columns
    df = int_frame_const_col
    result = df.apply(lambda x: [1, 2, 3], axis=1, result_type="broadcast")
    tm.assert_frame_equal(result, df)


def test_apply_broadcast_series_lambda_func(int_frame_const_col):
    df = int_frame_const_col
    result = df.apply(
        lambda x: pd.Series([1, 2, 3], index=list("abc")),
        axis=1,
        result_type="broadcast",
    )
    expected = df.copy()
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize("axis", [0, 1])
def test_apply_raw_float_frame(float_frame, axis, engine):
    if engine == "numba":
        pytest.skip("numba can't handle when UDF returns None.")

    def _assert_raw(x):
        assert isinstance(x, np.ndarray)
        assert x.ndim == 1

    float_frame.apply(_assert_raw, axis=axis, engine=engine, raw=True)


@pytest.mark.parametrize("axis", [0, 1])
def test_apply_raw_float_frame_lambda(float_frame, axis, engine):
    result = float_frame.apply(np.mean, axis=axis, engine=engine, raw=True)
    expected = float_frame.apply(lambda x: x.values.mean(), axis=axis)
    tm.assert_series_equal(result, expected)


def test_apply_raw_float_frame_no_reduction(float_frame, engine):
    # no reduction
    result = float_frame.apply(lambda x: x * 2, engine=engine, raw=True)
    expected = float_frame * 2
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize("axis", [0, 1])
def test_apply_raw_mixed_type_frame(axis, engine):
    if engine == "numba":
        pytest.skip("isinstance check doesn't work with numba")

    def _assert_raw(x):
        assert isinstance(x, np.ndarray)
        assert x.ndim == 1

    # Mixed dtype (GH-32423)
    df = pd.DataFrame(
        {
            "a": 1.0,
            "b": 2,
            "c": "foo",
            "float32": np.array([1.0] * 10, dtype="float32"),
            "int32": np.array([1] * 10, dtype="int32"),
        },
        index=np.arange(10),
    )
    df.apply(_assert_raw, axis=axis, engine=engine, raw=True)


def test_apply_axis1(float_frame):
    d = float_frame.index[0]
    result = float_frame.apply(np.mean, axis=1)[d]
    expected = np.mean(float_frame.xs(d))
    assert result == expected


def test_apply_mixed_dtype_corner():
    df = pd.DataFrame({"A": ["foo"], "B": [1.0]})
    result = df[:0].apply(np.mean, axis=1)
    # the result here is actually kind of ambiguous, should it be a Series
    # or a DataFrame?
    expected = pd.Series(dtype=np.float64)
    tm.assert_series_equal(result, expected)


def test_apply_mixed_dtype_corner_indexing():
    df = pd.DataFrame({"A": ["foo"], "B": [1.0]})
    result = df.apply(lambda x: x["A"], axis=1)
    expected = pd.Series(["foo"], index=range(1))
    tm.assert_series_equal(result, expected)

    result = df.apply(lambda x: x["B"], axis=1)
    expected = pd.Series([1.0], index=range(1))
    tm.assert_series_equal(result, expected)


@pytest.mark.filterwarnings("ignore::RuntimeWarning")
@pytest.mark.parametrize("ax", ["index", "columns"])
@pytest.mark.parametrize(
    "func", [lambda x: x, lambda x: x.mean()], ids=["identity", "mean"]
)
@pytest.mark.parametrize("raw", [True, False])
@pytest.mark.parametrize("axis", [0, 1])
def test_apply_empty_infer_type(ax, func, raw, axis, engine, request):
    df = pd.DataFrame(**{ax: ["a", "b", "c"]})

    with np.errstate(all="ignore"):
        test_res = func(np.array([], dtype="f8"))
        is_reduction = not isinstance(test_res, np.ndarray)

        result = df.apply(func, axis=axis, engine=engine, raw=raw)
        if is_reduction:
            agg_axis = df._get_agg_axis(axis)
            assert isinstance(result, pd.Series)
            assert result.index is agg_axis
        else:
            assert isinstance(result, pd.DataFrame)


def test_apply_empty_infer_type_broadcast():
    no_cols = pd.DataFrame(index=["a", "b", "c"])
    result = no_cols.apply(lambda x: x.mean(), result_type="broadcast")
    assert isinstance(result, pd.DataFrame)


def test_apply_with_args_kwds_add_some(float_frame):
    def add_some(x, howmuch=0):
        return x + howmuch

    result = float_frame.apply(add_some, howmuch=2)
    expected = float_frame.apply(lambda x: x + 2)
    tm.assert_frame_equal(result, expected)


def test_apply_with_args_kwds_agg_and_add(float_frame):
    def agg_and_add(x, howmuch=0):
        return x.mean() + howmuch

    result = float_frame.apply(agg_and_add, howmuch=2)
    expected = float_frame.apply(lambda x: x.mean() + 2)
    tm.assert_series_equal(result, expected)


def test_apply_with_args_kwds_subtract_and_divide(float_frame):
    def subtract_and_divide(x, sub, divide=1):
        return (x - sub) / divide

    result = float_frame.apply(subtract_and_divide, args=(2,), divide=2)
    expected = float_frame.apply(lambda x: (x - 2.0) / 2.0)
    tm.assert_frame_equal(result, expected)


def test_apply_yield_list(float_frame):
    result = float_frame.apply(list)
    tm.assert_frame_equal(result, float_frame)


def test_apply_reduce_Series(float_frame):
    float_frame.iloc[::2, float_frame.columns.get_loc("A")] = np.nan
    expected = float_frame.mean(axis=1)
    result = float_frame.apply(np.mean, axis=1)
    tm.assert_series_equal(result, expected)


def test_apply_reduce_to_dict():
    # GH 25196 37544
    data = pd.DataFrame([[1, 2], [3, 4]], columns=["c0", "c1"], index=["i0", "i1"])

    result = data.apply(dict, axis=0)
    expected = pd.Series([{"i0": 1, "i1": 3}, {"i0": 2, "i1": 4}], index=data.columns)
    tm.assert_series_equal(result, expected)

    result = data.apply(dict, axis=1)
    expected = pd.Series([{"c0": 1, "c1": 2}, {"c0": 3, "c1": 4}], index=data.index)
    tm.assert_series_equal(result, expected)


def test_apply_differently_indexed():
    df = pd.DataFrame(np.random.default_rng(2).standard_normal((20, 10)))

    result = df.apply(pd.Series.describe, axis=0)
    expected = pd.DataFrame(
        {i: v.describe() for i, v in df.items()}, columns=df.columns
    )
    tm.assert_frame_equal(result, expected)

    result = df.apply(pd.Series.describe, axis=1)
    expected = pd.DataFrame(
        {i: v.describe() for i, v in df.T.items()}, columns=df.index
    ).T
    tm.assert_frame_equal(result, expected)


def test_apply_bug():
    # GH 6125
    positions = pd.DataFrame(
        [
            [1, "ABC0", 50],
            [1, "YUM0", 20],
            [1, "DEF0", 20],
            [2, "ABC1", 50],
            [2, "YUM1", 20],
            [2, "DEF1", 20],
        ],
        columns=["a", "market", "position"],
    )

    def f(r):
        return r["market"]

    expected = positions.apply(f, axis=1)

    positions = pd.DataFrame(
        [
            [datetime(2013, 1, 1), "ABC0", 50],
            [datetime(2013, 1, 2), "YUM0", 20],
            [datetime(2013, 1, 3), "DEF0", 20],
            [datetime(2013, 1, 4), "ABC1", 50],
            [datetime(2013, 1, 5), "YUM1", 20],
            [datetime(2013, 1, 6), "DEF1", 20],
        ],
        columns=["a", "market", "position"],
    )
    result = positions.apply(f, axis=1)
    tm.assert_series_equal(result, expected)


def test_apply_convert_objects():
    expected = pd.DataFrame(
        {
            "A": [
                "foo",
                "foo",
                "foo",
                "foo",
                "bar",
                "bar",
                "bar",
                "bar",
                "foo",
                "foo",
                "foo",
            ],
            "B": [
                "one",
                "one",
                "one",
                "two",
                "one",
                "one",
                "one",
                "two",
                "two",
                "two",
                "one",
            ],
            "C": [
                "dull",
                "dull",
                "shiny",
                "dull",
                "dull",
                "shiny",
                "shiny",
                "dull",
                "shiny",
                "shiny",
                "shiny",
            ],
            "D": np.random.default_rng(2).standard_normal(11),
            "E": np.random.default_rng(2).standard_normal(11),
            "F": np.random.default_rng(2).standard_normal(11),
        }
    )

    result = expected.apply(lambda x: x, axis=1)
    tm.assert_frame_equal(result, expected)


def test_apply_attach_name(float_frame):
    result = float_frame.apply(lambda x: x.name)
    expected = pd.Series(float_frame.columns, index=float_frame.columns)
    tm.assert_series_equal(result, expected)


def test_apply_attach_name_axis1(float_frame):
    result = float_frame.apply(lambda x: x.name, axis=1)
    expected = pd.Series(float_frame.index, index=float_frame.index)
    tm.assert_series_equal(result, expected)


def test_apply_attach_name_non_reduction(float_frame):
    # non-reductions
    result = float_frame.apply(lambda x: np.repeat(x.name, len(x)))
    expected = pd.DataFrame(
        np.tile(float_frame.columns, (len(float_frame.index), 1)),
        index=float_frame.index,
        columns=float_frame.columns,
    )
    tm.assert_frame_equal(result, expected)


def test_apply_attach_name_non_reduction_axis1(float_frame):
    result = float_frame.apply(lambda x: np.repeat(x.name, len(x)), axis=1)
    expected = pd.Series(
        np.repeat(t[0], len(float_frame.columns)) for t in float_frame.itertuples()
    )
    expected.index = float_frame.index
    tm.assert_series_equal(result, expected)


def test_apply_multi_index():
    index = pd.MultiIndex.from_arrays([["a", "a", "b"], ["c", "d", "d"]])
    s = pd.DataFrame([[1, 2], [3, 4], [5, 6]], index=index, columns=["col1", "col2"])
    result = s.apply(lambda x: pd.Series({"min": min(x), "max": max(x)}), 1)
    expected = pd.DataFrame(
        [[1, 2], [3, 4], [5, 6]], index=index, columns=["min", "max"]
    )
    tm.assert_frame_equal(result, expected, check_like=True)


@pytest.mark.parametrize(
    "df, dicts",
    [
        [
            pd.DataFrame([["foo", "bar"], ["spam", "eggs"]]),
            pd.Series([{0: "foo", 1: "spam"}, {0: "bar", 1: "eggs"}]),
        ],
        [pd.DataFrame([[0, 1], [2, 3]]), pd.Series([{0: 0, 1: 2}, {0: 1, 1: 3}])],
    ],
)
def test_apply_dict(df, dicts):
    # GH 8735
    fn = lambda x: x.to_dict()
    reduce_true = df.apply(fn, result_type="reduce")
    reduce_false = df.apply(fn, result_type="expand")
    reduce_none = df.apply(fn)

    tm.assert_series_equal(reduce_true, dicts)
    tm.assert_frame_equal(reduce_false, df)
    tm.assert_series_equal(reduce_none, dicts)


def test_apply_non_numpy_dtype():
    # GH 12244
    df = pd.DataFrame(
        {"dt": pd.date_range("2015-01-01", periods=3, tz="Europe/Brussels")}
    )
    result = df.apply(lambda x: x)
    tm.assert_frame_equal(result, df)

    result = df.apply(lambda x: x + pd.Timedelta("1day"))
    expected = pd.DataFrame(
        {"dt": pd.date_range("2015-01-02", periods=3, tz="Europe/Brussels")}
    )
    tm.assert_frame_equal(result, expected)


def test_apply_non_numpy_dtype_category():
    df = pd.DataFrame({"dt": ["a", "b", "c", "a"]}, dtype="category")
    result = df.apply(lambda x: x)
    tm.assert_frame_equal(result, df)


def test_apply_dup_names_multi_agg():
    # GH 21063
    df = pd.DataFrame([[0, 1], [2, 3]], columns=["a", "a"])
    expected = pd.DataFrame([[0, 1]], columns=["a", "a"], index=["min"])
    result = df.agg(["min"])

    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize("op", ["apply", "agg"])
def test_apply_nested_result_axis_1(op):
    # GH 13820
    def apply_list(row):
        return [2 * row["A"], 2 * row["C"], 2 * row["B"]]

    df = pd.DataFrame(np.zeros((4, 4)), columns=list("ABCD"))
    result = getattr(df, op)(apply_list, axis=1)
    expected = pd.Series(
        [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]]
    )
    tm.assert_series_equal(result, expected)


def test_apply_noreduction_tzaware_object():
    # https://github.com/pandas-dev/pandas/issues/31505
    expected = pd.DataFrame(
        {"foo": [pd.Timestamp("2020", tz="UTC")]}, dtype="datetime64[ns, UTC]"
    )
    result = expected.apply(lambda x: x)
    tm.assert_frame_equal(result, expected)
    result = expected.apply(lambda x: x.copy())
    tm.assert_frame_equal(result, expected)


def test_apply_function_runs_once():
    # https://github.com/pandas-dev/pandas/issues/30815

    df = pd.DataFrame({"a": [1, 2, 3]})
    names = []  # Save row names function is applied to

    def reducing_function(row):
        names.append(row.name)

    def non_reducing_function(row):
        names.append(row.name)
        return row

    for func in [reducing_function, non_reducing_function]:
        del names[:]

        df.apply(func, axis=1)
        assert names == list(df.index)


def test_apply_raw_function_runs_once(engine):
    # https://github.com/pandas-dev/pandas/issues/34506
    if engine == "numba":
        pytest.skip("appending to list outside of numba func is not supported")

    df = pd.DataFrame({"a": [1, 2, 3]})
    values = []  # Save row values function is applied to

    def reducing_function(row):
        values.extend(row)

    def non_reducing_function(row):
        values.extend(row)
        return row

    for func in [reducing_function, non_reducing_function]:
        del values[:]

        df.apply(func, engine=engine, raw=True, axis=1)
        assert values == list(df.a.to_list())


def test_apply_with_byte_string():
    # GH 34529
    df = pd.DataFrame(np.array([b"abcd", b"efgh"]), columns=["col"])
    expected = pd.DataFrame(np.array([b"abcd", b"efgh"]), columns=["col"], dtype=object)
    # After we make the apply we expect a dataframe just
    # like the original but with the object datatype
    result = df.apply(lambda x: x.astype("object"))
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize("val", ["asd", 12, None, np.nan])
def test_apply_category_equalness(val):
    # Check if categorical comparisons on apply, GH 21239
    df_values = ["asd", None, 12, "asd", "cde", np.nan]
    df = pd.DataFrame({"a": df_values}, dtype="category")

    result = df.a.apply(lambda x: x == val)
    expected = pd.Series(
        [False if pd.isnull(x) else x == val for x in df_values], name="a"
    )
    # False since behavior of NaN for categorical dtype has been changed (GH 59966)
    tm.assert_series_equal(result, expected)


# the user has supplied an opaque UDF where
# they are transforming the input that requires
# us to infer the output


def test_infer_row_shape():
    # GH 17437
    # if row shape is changing, infer it
    df = pd.DataFrame(np.random.default_rng(2).random((10, 2)))
    result = df.apply(np.fft.fft, axis=0).shape
    assert result == (10, 2)

    result = df.apply(np.fft.rfft, axis=0).shape
    assert result == (6, 2)


@pytest.mark.parametrize(
    "ops, by_row, expected",
    [
        ({"a": lambda x: x + 1}, "compat", pd.DataFrame({"a": [2, 3]})),
        ({"a": lambda x: x + 1}, False, pd.DataFrame({"a": [2, 3]})),
        ({"a": lambda x: x.sum()}, "compat", pd.Series({"a": 3})),
        ({"a": lambda x: x.sum()}, False, pd.Series({"a": 3})),
        (
            {"a": ["sum", np.sum, lambda x: x.sum()]},
            "compat",
            pd.DataFrame({"a": [3, 3, 3]}, index=["sum", "sum", "<lambda>"]),
        ),
        (
            {"a": ["sum", np.sum, lambda x: x.sum()]},
            False,
            pd.DataFrame({"a": [3, 3, 3]}, index=["sum", "sum", "<lambda>"]),
        ),
        ({"a": lambda x: 1}, "compat", pd.DataFrame({"a": [1, 1]})),
        ({"a": lambda x: 1}, False, pd.Series({"a": 1})),
    ],
)
def test_dictlike_lambda(ops, by_row, expected):
    # GH53601
    df = pd.DataFrame({"a": [1, 2]})
    result = df.apply(ops, by_row=by_row)
    tm.assert_equal(result, expected)


@pytest.mark.parametrize(
    "ops",
    [
        {"a": lambda x: x + 1},
        {"a": lambda x: x.sum()},
        {"a": ["sum", np.sum, lambda x: x.sum()]},
        {"a": lambda x: 1},
    ],
)
def test_dictlike_lambda_raises(ops):
    # GH53601
    df = pd.DataFrame({"a": [1, 2]})
    with pytest.raises(ValueError, match="by_row=True not allowed"):
        df.apply(ops, by_row=True)


def test_with_dictlike_columns():
    # GH 17602
    df = pd.DataFrame([[1, 2], [1, 2]], columns=["a", "b"])
    result = df.apply(lambda x: {"s": x["a"] + x["b"]}, axis=1)
    expected = pd.Series([{"s": 3} for t in df.itertuples()])
    tm.assert_series_equal(result, expected)

    df["tm"] = [
        pd.Timestamp("2017-05-01 00:00:00"),
        pd.Timestamp("2017-05-02 00:00:00"),
    ]
    result = df.apply(lambda x: {"s": x["a"] + x["b"]}, axis=1)
    tm.assert_series_equal(result, expected)

    # compose a series
    result = (df["a"] + df["b"]).apply(lambda x: {"s": x})
    expected = pd.Series([{"s": 3}, {"s": 3}])
    tm.assert_series_equal(result, expected)


def test_with_dictlike_columns_with_datetime():
    # GH 18775
    df = pd.DataFrame()
    df["author"] = ["X", "Y", "Z"]
    df["publisher"] = ["BBC", "NBC", "N24"]
    df["date"] = pd.to_datetime(
        ["17-10-2010 07:15:30", "13-05-2011 08:20:35", "15-01-2013 09:09:09"],
        dayfirst=True,
    )
    result = df.apply(lambda x: {}, axis=1)
    expected = pd.Series([{}, {}, {}])
    tm.assert_series_equal(result, expected)


def test_with_dictlike_columns_with_infer():
    # GH 17602
    df = pd.DataFrame([[1, 2], [1, 2]], columns=["a", "b"])
    result = df.apply(lambda x: {"s": x["a"] + x["b"]}, axis=1, result_type="expand")
    expected = pd.DataFrame({"s": [3, 3]})
    tm.assert_frame_equal(result, expected)

    df["tm"] = [
        pd.Timestamp("2017-05-01 00:00:00"),
        pd.Timestamp("2017-05-02 00:00:00"),
    ]
    result = df.apply(lambda x: {"s": x["a"] + x["b"]}, axis=1, result_type="expand")
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize(
    "ops, by_row, expected",
    [
        ([lambda x: x + 1], "compat", pd.DataFrame({("a", "<lambda>"): [2, 3]})),
        ([lambda x: x + 1], False, pd.DataFrame({("a", "<lambda>"): [2, 3]})),
        ([lambda x: x.sum()], "compat", pd.DataFrame({"a": [3]}, index=["<lambda>"])),
        ([lambda x: x.sum()], False, pd.DataFrame({"a": [3]}, index=["<lambda>"])),
        (
            ["sum", np.sum, lambda x: x.sum()],
            "compat",
            pd.DataFrame({"a": [3, 3, 3]}, index=["sum", "sum", "<lambda>"]),
        ),
        (
            ["sum", np.sum, lambda x: x.sum()],
            False,
            pd.DataFrame({"a": [3, 3, 3]}, index=["sum", "sum", "<lambda>"]),
        ),
        (
            [lambda x: x + 1, lambda x: 3],
            "compat",
            pd.DataFrame(
                [[2, 3], [3, 3]], columns=[["a", "a"], ["<lambda>", "<lambda>"]]
            ),
        ),
        (
            [lambda x: 2, lambda x: 3],
            False,
            pd.DataFrame({"a": [2, 3]}, ["<lambda>", "<lambda>"]),
        ),
    ],
)
def test_listlike_lambda(ops, by_row, expected):
    # GH53601
    df = pd.DataFrame({"a": [1, 2]})
    result = df.apply(ops, by_row=by_row)
    tm.assert_equal(result, expected)


def test_listlike_datetime_index_unsorted():
    # https://github.com/pandas-dev/pandas/pull/62843
    values = [datetime(2024, 1, 1), datetime(2024, 1, 2), datetime(2024, 1, 3)]
    df = pd.DataFrame({"a": [1, 2]}, index=[values[1], values[0]])
    result = df.apply([lambda x: x, lambda x: x.shift(freq="D")], by_row=False)
    expected = pd.DataFrame(
        [[1.0, 2.0], [2.0, np.nan], [np.nan, 1.0]],
        index=[values[1], values[0], values[2]],
        columns=pd.MultiIndex([["a"], ["<lambda>"]], codes=[[0, 0], [0, 0]]),
    )
    tm.assert_frame_equal(result, expected)


def test_dictlike_datetime_index_unsorted():
    # https://github.com/pandas-dev/pandas/pull/62843
    values = [datetime(2024, 1, 1), datetime(2024, 1, 2), datetime(2024, 1, 3)]
    df = pd.DataFrame({"a": [1, 2], "b": [3, 4]}, index=[values[1], values[0]])
    result = df.apply(
        {"a": lambda x: x, "b": lambda x: x.shift(freq="D")}, by_row=False
    )
    expected = pd.DataFrame(
        {
            "a": [1.0, 2.0, np.nan],
            "b": [4.0, np.nan, 3.0],
        },
        index=[values[1], values[0], values[2]],
    )
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize(
    "ops",
    [
        [lambda x: x + 1],
        [lambda x: x.sum()],
        ["sum", np.sum, lambda x: x.sum()],
        [lambda x: x + 1, lambda x: 3],
    ],
)
def test_listlike_lambda_raises(ops):
    # GH53601
    df = pd.DataFrame({"a": [1, 2]})
    with pytest.raises(ValueError, match="by_row=True not allowed"):
        df.apply(ops, by_row=True)


def test_with_listlike_columns():
    # GH 17348
    df = pd.DataFrame(
        {
            "a": pd.Series(np.random.default_rng(2).standard_normal(4)),
            "b": ["a", "list", "of", "words"],
            "ts": pd.date_range("2016-10-01", periods=4, freq="h"),
        }
    )

    result = df[["a", "b"]].apply(tuple, axis=1)
    expected = pd.Series([t[1:] for t in df[["a", "b"]].itertuples()])
    tm.assert_series_equal(result, expected)

    result = df[["a", "ts"]].apply(tuple, axis=1)
    expected = pd.Series([t[1:] for t in df[["a", "ts"]].itertuples()])
    tm.assert_series_equal(result, expected)


def test_with_listlike_columns_returning_list():
    # GH 18919
    df = pd.DataFrame(
        {"x": pd.Series([["a", "b"], ["q"]]), "y": pd.Series([["z"], ["q", "t"]])}
    )
    df.index = pd.MultiIndex.from_tuples([("i0", "j0"), ("i1", "j1")])

    result = df.apply(lambda row: [el for el in row["x"] if el in row["y"]], axis=1)
    expected = pd.Series([[], ["q"]], index=df.index)
    tm.assert_series_equal(result, expected)


def test_infer_output_shape_columns():
    # GH 18573

    df = pd.DataFrame(
        {
            "number": [1.0, 2.0],
            "string": ["foo", "bar"],
            "datetime": [
                pd.Timestamp("2017-11-29 03:30:00"),
                pd.Timestamp("2017-11-29 03:45:00"),
            ],
        }
    )
    result = df.apply(lambda row: (row.number, row.string), axis=1)
    expected = pd.Series([(t.number, t.string) for t in df.itertuples()])
    tm.assert_series_equal(result, expected)


def test_infer_output_shape_listlike_columns():
    # GH 16353

    df = pd.DataFrame(
        np.random.default_rng(2).standard_normal((6, 3)), columns=["A", "B", "C"]
    )

    result = df.apply(lambda x: [1, 2, 3], axis=1)
    expected = pd.Series([[1, 2, 3] for t in df.itertuples()])
    tm.assert_series_equal(result, expected)

    result = df.apply(lambda x: [1, 2], axis=1)
    expected = pd.Series([[1, 2] for t in df.itertuples()])
    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize("val", [1, 2])
def test_infer_output_shape_listlike_columns_np_func(val):
    # GH 17970
    df = pd.DataFrame({"a": [1, 2, 3]}, index=list("abc"))

    result = df.apply(lambda row: np.ones(val), axis=1)
    expected = pd.Series([np.ones(val) for t in df.itertuples()], index=df.index)
    tm.assert_series_equal(result, expected)


def test_infer_output_shape_listlike_columns_with_timestamp():
    # GH 17892
    df = pd.DataFrame(
        {
            "a": [
                pd.Timestamp("2010-02-01"),
                pd.Timestamp("2010-02-04"),
                pd.Timestamp("2010-02-05"),
                pd.Timestamp("2010-02-06"),
            ],
            "b": [9, 5, 4, 3],
            "c": [5, 3, 4, 2],
            "d": [1, 2, 3, 4],
        }
    )

    def fun(x):
        return (1, 2)

    result = df.apply(fun, axis=1)
    expected = pd.Series([(1, 2) for t in df.itertuples()])
    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize("lst", [[1, 2, 3], [1, 2]])
def test_consistent_coerce_for_shapes(lst):
    # we want column names to NOT be propagated
    # just because the shape matches the input shape
    df = pd.DataFrame(
        np.random.default_rng(2).standard_normal((4, 3)), columns=["A", "B", "C"]
    )

    result = df.apply(lambda x: lst, axis=1)
    expected = pd.Series([lst for t in df.itertuples()])
    tm.assert_series_equal(result, expected)


def test_consistent_names(int_frame_const_col):
    # if a Series is returned, we should use the resulting index names
    df = int_frame_const_col

    result = df.apply(
        lambda x: pd.Series([1, 2, 3], index=["test", "other", "cols"]), axis=1
    )
    expected = int_frame_const_col.rename(
        columns={"A": "test", "B": "other", "C": "cols"}
    )
    tm.assert_frame_equal(result, expected)

    result = df.apply(lambda x: pd.Series([1, 2], index=["test", "other"]), axis=1)
    expected = expected[["test", "other"]]
    tm.assert_frame_equal(result, expected)


def test_result_type(int_frame_const_col):
    # result_type should be consistent no matter which
    # path we take in the code
    df = int_frame_const_col

    result = df.apply(lambda x: [1, 2, 3], axis=1, result_type="expand")
    expected = df.copy()
    expected.columns = range(3)
    tm.assert_frame_equal(result, expected)


def test_result_type_shorter_list(int_frame_const_col):
    # result_type should be consistent no matter which
    # path we take in the code
    df = int_frame_const_col
    result = df.apply(lambda x: [1, 2], axis=1, result_type="expand")
    expected = df[["A", "B"]].copy()
    expected.columns = range(2)
    tm.assert_frame_equal(result, expected)


def test_result_type_broadcast(int_frame_const_col, request, engine):
    # result_type should be consistent no matter which
    # path we take in the code
    if engine == "numba":
        mark = pytest.mark.xfail(reason="numba engine doesn't support list return")
        request.node.add_marker(mark)
    df = int_frame_const_col
    if engine is MockEngineDecorator:
        with pytest.raises(
            NotImplementedError,
            match="result_type='broadcast' only implemented for the default engine",
        ):
            df.apply(
                lambda x: [1, 2, 3], axis=1, result_type="broadcast", engine=engine
            )
    else:
        # broadcast result
        result = df.apply(
            lambda x: [1, 2, 3], axis=1, result_type="broadcast", engine=engine
        )
        expected = df.copy()
        tm.assert_frame_equal(result, expected)


def test_result_type_broadcast_series_func(int_frame_const_col, engine, request):
    # result_type should be consistent no matter which
    # path we take in the code
    if engine == "numba":
        mark = pytest.mark.xfail(
            reason="numba Series constructor only support ndarrays not list data"
        )
        request.node.add_marker(mark)
    df = int_frame_const_col
    columns = ["other", "col", "names"]

    if engine is MockEngineDecorator:
        with pytest.raises(
            NotImplementedError,
            match="result_type='broadcast' only implemented for the default engine",
        ):
            df.apply(
                lambda x: pd.Series([1, 2, 3], index=columns),
                axis=1,
                result_type="broadcast",
                engine=engine,
            )
    else:
        result = df.apply(
            lambda x: pd.Series([1, 2, 3], index=columns),
            axis=1,
            result_type="broadcast",
            engine=engine,
        )
        expected = df.copy()
        tm.assert_frame_equal(result, expected)


def test_result_type_series_result(int_frame_const_col, engine, request):
    # result_type should be consistent no matter which
    # path we take in the code
    if engine == "numba":
        mark = pytest.mark.xfail(
            reason="numba Series constructor only support ndarrays not list data"
        )
        request.node.add_marker(mark)
    df = int_frame_const_col
    # series result
    result = df.apply(
        lambda x: pd.Series([1, 2, 3], index=x.index), axis=1, engine=engine
    )
    expected = df.copy()
    tm.assert_frame_equal(result, expected)


def test_result_type_series_result_other_index(int_frame_const_col, engine, request):
    # result_type should be consistent no matter which
    # path we take in the code

    if engine == "numba":
        mark = pytest.mark.xfail(
            reason="no support in numba Series constructor for list of columns"
        )
        request.node.add_marker(mark)
    df = int_frame_const_col
    # series result with other index
    columns = ["other", "col", "names"]
    result = df.apply(
        lambda x: pd.Series([1, 2, 3], index=columns), axis=1, engine=engine
    )
    expected = df.copy()
    expected.columns = columns
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize(
    "box",
    [lambda x: list(x), lambda x: tuple(x), lambda x: np.array(x, dtype="int64")],
    ids=["list", "tuple", "array"],
)
def test_consistency_for_boxed(box, int_frame_const_col):
    # passing an array or list should not affect the output shape
    df = int_frame_const_col

    result = df.apply(lambda x: box([1, 2]), axis=1)
    expected = pd.Series([box([1, 2]) for t in df.itertuples()])
    tm.assert_series_equal(result, expected)

    result = df.apply(lambda x: box([1, 2]), axis=1, result_type="expand")
    expected = int_frame_const_col[["A", "B"]].rename(columns={"A": 0, "B": 1})
    tm.assert_frame_equal(result, expected)


def test_agg_transform(axis, float_frame):
    other_axis = 1 if axis in {0, "index"} else 0

    with np.errstate(all="ignore"):
        f_abs = np.abs(float_frame)
        f_sqrt = np.sqrt(float_frame)

        # ufunc
        expected = f_sqrt.copy()
        result = float_frame.apply(np.sqrt, axis=axis)
        tm.assert_frame_equal(result, expected)

        # list-like
        result = float_frame.apply([np.sqrt], axis=axis)
        expected = f_sqrt.copy()
        if axis in {0, "index"}:
            expected.columns = pd.MultiIndex.from_product(
                [float_frame.columns, ["sqrt"]]
            )
        else:
            expected.index = pd.MultiIndex.from_product([float_frame.index, ["sqrt"]])
        tm.assert_frame_equal(result, expected)

        # multiple items in list
        # these are in the order as if we are applying both
        # functions per series and then concatting
        result = float_frame.apply([np.abs, np.sqrt], axis=axis)
        expected = zip_frames([f_abs, f_sqrt], axis=other_axis)
        if axis in {0, "index"}:
            expected.columns = pd.MultiIndex.from_product(
                [float_frame.columns, ["absolute", "sqrt"]]
            )
        else:
            expected.index = pd.MultiIndex.from_product(
                [float_frame.index, ["absolute", "sqrt"]]
            )
        tm.assert_frame_equal(result, expected)


def test_demo():
    # demonstration tests
    df = pd.DataFrame({"A": range(5), "B": 5})

    result = df.agg(["min", "max"])
    expected = pd.DataFrame(
        {"A": [0, 4], "B": [5, 5]}, columns=["A", "B"], index=["min", "max"]
    )
    tm.assert_frame_equal(result, expected)


def test_demo_dict_agg():
    # demonstration tests
    df = pd.DataFrame({"A": range(5), "B": 5})
    result = df.agg({"A": ["min", "max"], "B": ["sum", "max"]})
    expected = pd.DataFrame(
        {"A": [4.0, 0.0, np.nan], "B": [5.0, np.nan, 25.0]},
        columns=["A", "B"],
        index=["max", "min", "sum"],
    )
    tm.assert_frame_equal(result.reindex_like(expected), expected)


def test_agg_with_name_as_column_name():
    # GH 36212 - Column name is "name"
    data = {"name": ["foo", "bar"]}
    df = pd.DataFrame(data)

    # result's name should be None
    result = df.agg({"name": "count"})
    expected = pd.Series({"name": 2})
    tm.assert_series_equal(result, expected)

    # Check if name is still preserved when aggregating series instead
    result = df["name"].agg({"name": "count"})
    expected = pd.Series({"name": 2}, name="name")
    tm.assert_series_equal(result, expected)


def test_agg_multiple_mixed():
    # GH 20909
    mdf = pd.DataFrame(
        {
            "A": [1, 2, 3],
            "B": [1.0, 2.0, 3.0],
            "C": ["foo", "bar", "baz"],
        }
    )
    expected = pd.DataFrame(
        {
            "A": [1, 6],
            "B": [1.0, 6.0],
            "C": ["bar", "foobarbaz"],
        },
        index=["min", "sum"],
    )
    # sorted index
    result = mdf.agg(["min", "sum"])
    tm.assert_frame_equal(result, expected)

    result = mdf[["C", "B", "A"]].agg(["sum", "min"])
    # GH40420: the result of .agg should have an index that is sorted
    # according to the arguments provided to agg.
    expected = expected[["C", "B", "A"]].reindex(["sum", "min"])
    tm.assert_frame_equal(result, expected)


def test_agg_multiple_mixed_numeric_only_column_order():
    # GH#65218
    mdf = pd.DataFrame(
        {
            "A": [1, 2, 3],
            "C": ["foo", "bar", "baz"],
            "B": [1.0, 2.0, 3.0],
        }
    )
    expected = pd.DataFrame(
        {"A": [6.0, 2.0], "B": [6.0, 2.0]},
        index=["sum", "mean"],
    )
    result = mdf.agg(["sum", "mean"], numeric_only=True)
    tm.assert_frame_equal(result, expected)


def test_agg_multiple_mixed_numeric_only_all_non_numeric():
    # GH#65218
    mdf = pd.DataFrame({"C": ["foo", "bar", "baz"], "D": ["a", "b", "c"]})
    expected = pd.DataFrame(index=["sum", "mean"], columns=mdf.columns[:0])
    result = mdf.agg(["sum", "mean"], numeric_only=True)
    tm.assert_frame_equal(result, expected)


def test_agg_multiple_mixed_bool_only():
    # GH#65218
    mdf = pd.DataFrame(
        {
            "A": [True, False, True],
            "B": [1, 2, 3],
            "C": ["foo", "bar", "baz"],
        }
    )
    expected = pd.DataFrame({"A": [True, False]}, index=["any", "all"])
    result = mdf.agg(["any", "all"], bool_only=True)
    tm.assert_frame_equal(result, expected)


def test_agg_multiple_mixed_raises():
    # GH 20909
    mdf = pd.DataFrame(
        {
            "A": [1, 2, 3],
            "B": [1.0, 2.0, 3.0],
            "C": ["foo", "bar", "baz"],
            "D": pd.date_range("20130101", periods=3),
        }
    )

    # sorted index
    msg = "does not support operation"
    with pytest.raises(TypeError, match=msg):
        mdf.agg(["min", "sum"])

    with pytest.raises(TypeError, match=msg):
        mdf[["D", "C", "B", "A"]].agg(["sum", "min"])


def test_agg_reduce(axis, float_frame):
    other_axis = 1 if axis in {0, "index"} else 0
    name1, name2 = float_frame.axes[other_axis].unique()[:2].sort_values()

    # all reducers
    expected = pd.concat(
        [
            float_frame.mean(axis=axis),
            float_frame.max(axis=axis),
            float_frame.sum(axis=axis),
        ],
        axis=1,
    )
    expected.columns = ["mean", "max", "sum"]
    expected = expected.T if axis in {0, "index"} else expected

    result = float_frame.agg(["mean", "max", "sum"], axis=axis)
    tm.assert_frame_equal(result, expected)

    # dict input with scalars
    func = {name1: "mean", name2: "sum"}
    result = float_frame.agg(func, axis=axis)
    expected = pd.Series(
        [
            float_frame.loc(other_axis)[name1].mean(),
            float_frame.loc(other_axis)[name2].sum(),
        ],
        index=[name1, name2],
    )
    tm.assert_series_equal(result, expected)

    # dict input with lists
    func = {name1: ["mean"], name2: ["sum"]}
    result = float_frame.agg(func, axis=axis)
    expected = pd.DataFrame(
        {
            name1: pd.Series(
                [float_frame.loc(other_axis)[name1].mean()], index=["mean"]
            ),
            name2: pd.Series([float_frame.loc(other_axis)[name2].sum()], index=["sum"]),
        }
    )
    expected = expected.T if axis in {1, "columns"} else expected
    tm.assert_frame_equal(result, expected)

    # dict input with lists with multiple
    func = {name1: ["mean", "sum"], name2: ["sum", "max"]}
    result = float_frame.agg(func, axis=axis)
    expected = pd.concat(
        {
            name1: pd.Series(
                [
                    float_frame.loc(other_axis)[name1].mean(),
                    float_frame.loc(other_axis)[name1].sum(),
                ],
                index=["mean", "sum"],
            ),
            name2: pd.Series(
                [
                    float_frame.loc(other_axis)[name2].sum(),
                    float_frame.loc(other_axis)[name2].max(),
                ],
                index=["sum", "max"],
            ),
        },
        axis=1,
    )
    expected = expected.T if axis in {1, "columns"} else expected
    tm.assert_frame_equal(result, expected)


def test_named_agg_reduce_axis1_raises(float_frame):
    name1, name2 = float_frame.axes[0].unique()[:2].sort_values()
    msg = "Named aggregation is not supported when axis=1."
    for axis in [1, "columns"]:
        with pytest.raises(NotImplementedError, match=msg):
            float_frame.agg(row1=(name1, "sum"), row2=(name2, "max"), axis=axis)


def test_nuiscance_columns():
    # GH 15015
    df = pd.DataFrame(
        {
            "A": [1, 2, 3],
            "B": [1.0, 2.0, 3.0],
            "C": ["foo", "bar", "baz"],
            "D": pd.date_range("20130101", periods=3),
        }
    )

    result = df.agg("min")
    expected = pd.Series([1, 1.0, "bar", pd.Timestamp("20130101")], index=df.columns)
    tm.assert_series_equal(result, expected)

    result = df.agg(["min"])
    expected = pd.DataFrame(
        [[1, 1.0, "bar", pd.Timestamp("20130101")]],
        index=["min"],
        columns=df.columns,
    )
    tm.assert_frame_equal(result, expected)

    msg = "does not support operation"
    with pytest.raises(TypeError, match=msg):
        df.agg("sum")

    result = df[["A", "B", "C"]].agg("sum")
    expected = pd.Series([6, 6.0, "foobarbaz"], index=["A", "B", "C"])
    tm.assert_series_equal(result, expected)

    msg = "does not support operation"
    with pytest.raises(TypeError, match=msg):
        df.agg(["sum"])


@pytest.mark.parametrize("how", ["agg", "apply"])
def test_non_callable_aggregates(how):
    # GH 16405
    # 'size' is a property of frame/series
    # validate that this is working
    # GH 39116 - expand to apply
    df = pd.DataFrame(
        {"A": [None, 2, 3], "B": [1.0, np.nan, 3.0], "C": ["foo", None, "bar"]}
    )

    # Function aggregate
    result = getattr(df, how)({"A": "count"})
    expected = pd.Series({"A": 2})

    tm.assert_series_equal(result, expected)

    # Non-function aggregate
    result = getattr(df, how)({"A": "size"})
    expected = pd.Series({"A": 3})

    tm.assert_series_equal(result, expected)

    # Mix function and non-function aggs
    result1 = getattr(df, how)(["count", "size"])
    result2 = getattr(df, how)(
        {"A": ["count", "size"], "B": ["count", "size"], "C": ["count", "size"]}
    )
    expected = pd.DataFrame(
        {
            "A": {"count": 2, "size": 3},
            "B": {"count": 2, "size": 3},
            "C": {"count": 2, "size": 3},
        }
    )

    tm.assert_frame_equal(result1, result2, check_like=True)
    tm.assert_frame_equal(result2, expected, check_like=True)

    # Just functional string arg is same as calling df.arg()
    result = getattr(df, how)("count")
    expected = df.count()

    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize("how", ["agg", "apply"])
def test_size_as_str(how, axis):
    # GH 39934
    df = pd.DataFrame(
        {"A": [None, 2, 3], "B": [1.0, np.nan, 3.0], "C": ["foo", None, "bar"]}
    )
    # Just a string attribute arg same as calling df.arg
    # on the columns
    result = getattr(df, how)("size", axis=axis)
    if axis in (0, "index"):
        expected = pd.Series(df.shape[0], index=df.columns)
    else:
        expected = pd.Series(df.shape[1], index=df.index)
    tm.assert_series_equal(result, expected)


def test_agg_listlike_result():
    # GH-29587 user defined function returning list-likes
    df = pd.DataFrame(
        {"A": [2, 2, 3], "B": [1.5, np.nan, 1.5], "C": ["foo", None, "bar"]}
    )

    def func(group_col):
        return list(group_col.dropna().unique())

    result = df.agg(func)
    expected = pd.Series([[2, 3], [1.5], ["foo", "bar"]], index=["A", "B", "C"])
    tm.assert_series_equal(result, expected)

    result = df.agg([func])
    expected = expected.to_frame("func").T
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize("axis", [0, 1])
@pytest.mark.parametrize(
    "args, kwargs",
    [
        ((1, 2, 3), {}),
        ((8, 7, 15), {}),
        ((1, 2), {}),
        ((1,), {"b": 2}),
        ((), {"a": 1, "b": 2}),
        ((), {"a": 2, "b": 1}),
        ((), {"a": 1, "b": 2, "c": 3}),
    ],
)
def test_agg_args_kwargs(axis, args, kwargs):
    def f(x, a, b, c=3):
        return x.sum() + (a + b) / c

    df = pd.DataFrame([[1, 2], [3, 4]])

    if axis == 0:
        expected = pd.Series([5.0, 7.0])
    else:
        expected = pd.Series([4.0, 8.0])

    result = df.agg(f, axis, *args, **kwargs)

    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize("num_cols", [2, 3, 5])
def test_frequency_is_original(num_cols, engine, request):
    # GH 22150
    if engine == "numba":
        mark = pytest.mark.xfail(reason="numba engine only supports numeric indices")
        request.node.add_marker(mark)
    index = pd.DatetimeIndex(["1950-06-30", "1952-10-24", "1953-05-29"])
    original = index.copy()
    df = pd.DataFrame(1, index=index, columns=range(num_cols))
    df.apply(lambda x: x, engine=engine)
    assert index.freq == original.freq


def test_apply_datetime_tz_issue(engine, request):
    # GH 29052

    if engine == "numba":
        mark = pytest.mark.xfail(
            reason="numba engine doesn't support non-numeric indexes"
        )
        request.node.add_marker(mark)

    timestamps = [
        pd.Timestamp("2019-03-15 12:34:31.909000+0000", tz="UTC"),
        pd.Timestamp("2019-03-15 12:34:34.359000+0000", tz="UTC"),
        pd.Timestamp("2019-03-15 12:34:34.660000+0000", tz="UTC"),
    ]
    df = pd.DataFrame(data=[0, 1, 2], index=timestamps)
    result = df.apply(lambda x: x.name, axis=1, engine=engine)
    expected = pd.Series(index=timestamps, data=timestamps)

    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize("df", [pd.DataFrame({"A": ["a", None], "B": ["c", "d"]})])
@pytest.mark.parametrize("method", ["min", "max", "sum"])
def test_mixed_column_raises(df, method, using_infer_string):
    # GH 16832
    if method == "sum" and not using_infer_string:
        msg = "|".join(
            [r'can only concatenate str \(not "int"\) to str', "does not support"]
        )
        with pytest.raises(TypeError, match=msg):
            getattr(df, method)()
    else:
        # GH#65500: object min/max fill NA from the same slice rather than
        # +/-inf, so they no longer raise when NA sits alongside strings
        getattr(df, method)()


@pytest.mark.parametrize("col", [1, 1.0, True, "a", np.nan])
def test_apply_dtype(col):
    # GH 31466
    df = pd.DataFrame([[1.0, col]], columns=["a", "b"])
    result = df.apply(lambda x: x.dtype)
    expected = df.dtypes

    tm.assert_series_equal(result, expected)


def test_apply_mutating():
    # GH#35462 case where applied func pins a new BlockManager to a row
    df = pd.DataFrame({"a": range(10), "b": range(10, 20)})
    df_orig = df.copy()

    def func(row):
        mgr = row._mgr
        row.loc["a"] += 1
        assert row._mgr is not mgr
        return row

    expected = df.copy()
    expected["a"] += 1

    result = df.apply(func, axis=1)

    tm.assert_frame_equal(result, expected)
    tm.assert_frame_equal(df, df_orig)


def test_apply_empty_list_reduce():
    # GH#35683 get columns correct
    df = pd.DataFrame([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10]], columns=["a", "b"])

    result = df.apply(lambda x: [], result_type="reduce")
    expected = pd.Series({"a": [], "b": []}, dtype=object)
    tm.assert_series_equal(result, expected)


def test_apply_no_suffix_index(engine, request):
    # GH36189
    if engine == "numba":
        mark = pytest.mark.xfail(
            reason="numba engine doesn't support list-likes/dict-like callables"
        )
        request.node.add_marker(mark)
    pdf = pd.DataFrame([[4, 9]] * 3, columns=["A", "B"])
    result = pdf.apply(["sum", lambda x: x.sum(), lambda x: x.sum()], engine=engine)
    expected = pd.DataFrame(
        {"A": [12, 12, 12], "B": [27, 27, 27]}, index=["sum", "<lambda>", "<lambda>"]
    )

    tm.assert_frame_equal(result, expected)


def test_apply_raw_returns_string(engine):
    # https://github.com/pandas-dev/pandas/issues/35940
    if engine == "numba":
        pytest.skip("No object dtype support in numba")
    df = pd.DataFrame({"A": ["aa", "bbb"]})
    result = df.apply(lambda x: x[0], engine=engine, axis=1, raw=True)
    expected = pd.Series(["aa", "bbb"])
    tm.assert_series_equal(result, expected)


def test_aggregation_func_column_order():
    # GH40420: the result of .agg should have an index that is sorted
    # according to the arguments provided to agg.
    df = pd.DataFrame(
        [
            (1, 0, 0),
            (2, 0, 0),
            (3, 0, 0),
            (4, 5, 4),
            (5, 6, 6),
            (6, 7, 7),
        ],
        columns=("att1", "att2", "att3"),
    )

    def sum_div2(s):
        return s.sum() / 2

    aggs = ["sum", sum_div2, "count", "min"]
    result = df.agg(aggs)
    expected = pd.DataFrame(
        {
            "att1": [21.0, 10.5, 6.0, 1.0],
            "att2": [18.0, 9.0, 6.0, 0.0],
            "att3": [17.0, 8.5, 6.0, 0.0],
        },
        index=["sum", "sum_div2", "count", "min"],
    )
    tm.assert_frame_equal(result, expected)


def test_apply_getitem_axis_1(engine, request):
    # GH 13427
    if engine == "numba":
        mark = pytest.mark.xfail(
            reason="numba engine not supporting duplicate index values"
        )
        request.node.add_marker(mark)
    df = pd.DataFrame({"a": [0, 1, 2], "b": [1, 2, 3]})
    result = df[["a", "a"]].apply(
        lambda x: x.iloc[0] + x.iloc[1], axis=1, engine=engine
    )
    expected = pd.Series([0, 2, 4])
    tm.assert_series_equal(result, expected)


def test_nuisance_depr_passes_through_warnings():
    # GH 43740
    # DataFrame.agg with list-likes may emit warnings for both individual
    # args and for entire columns, but we only want to emit once. We
    # catch and suppress the warnings for individual args, but need to make
    # sure if some other warnings were raised, they get passed through to
    # the user.

    def expected_warning(x):
        warnings.warn("Hello, World!")
        return x.sum()

    df = pd.DataFrame({"a": [1, 2, 3]})
    with tm.assert_produces_warning(UserWarning, match="Hello, World!"):
        df.agg([expected_warning])


def test_apply_type():
    # GH 46719
    df = pd.DataFrame(
        {"col1": [3, "string", float], "col2": [0.25, datetime(2020, 1, 1), np.nan]},
        index=["a", "b", "c"],
    )

    # axis=0
    result = df.apply(type, axis=0)
    expected = pd.Series({"col1": pd.Series, "col2": pd.Series})
    tm.assert_series_equal(result, expected)

    # axis=1
    result = df.apply(type, axis=1)
    expected = pd.Series({"a": pd.Series, "b": pd.Series, "c": pd.Series})
    tm.assert_series_equal(result, expected)


def test_apply_on_empty_dataframe(engine):
    # GH 39111
    df = pd.DataFrame({"a": [1, 2], "b": [3, 0]})
    result = df.head(0).apply(lambda x: max(x["a"], x["b"]), axis=1, engine=engine)
    expected = pd.Series([], dtype=np.float64)
    tm.assert_series_equal(result, expected)


def test_apply_return_list():
    df = pd.DataFrame({"a": [1, 2], "b": [2, 3]})
    result = df.apply(lambda x: [x.values])
    expected = pd.DataFrame({"a": [[1, 2]], "b": [[2, 3]]})
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize(
    "test, constant",
    [
        ({"a": [1, 2, 3], "b": [1, 1, 1]}, {"a": [1, 2, 3], "b": [1]}),
        ({"a": [2, 2, 2], "b": [1, 1, 1]}, {"a": [2], "b": [1]}),
    ],
)
def test_unique_agg_type_is_series(test, constant):
    # GH#22558
    df1 = pd.DataFrame(test)
    expected = pd.Series(data=constant, index=["a", "b"], dtype="object")
    aggregation = {"a": "unique", "b": "unique"}

    result = df1.agg(aggregation)

    tm.assert_series_equal(result, expected)


def test_any_apply_keyword_non_zero_axis_regression():
    # https://github.com/pandas-dev/pandas/issues/48656
    df = pd.DataFrame({"A": [1, 2, 0], "B": [0, 2, 0], "C": [0, 0, 0]})
    expected = pd.Series([True, True, False])
    tm.assert_series_equal(df.any(axis=1), expected)

    result = df.apply("any", axis=1)
    tm.assert_series_equal(result, expected)

    result = df.apply("any", 1)
    tm.assert_series_equal(result, expected)


def test_agg_mapping_func_deprecated():
    # GH 53325
    df = pd.DataFrame({"x": [1, 2, 3]})

    def foo1(x, a=1, c=0):
        return x + a + c

    def foo2(x, b=2, c=0):
        return x + b + c

    # single func already takes the vectorized path
    result = df.agg(foo1, 0, 3, c=4)
    expected = df + 7
    tm.assert_frame_equal(result, expected)

    result = df.agg([foo1, foo2], 0, 3, c=4)
    expected = pd.DataFrame(
        [[8, 8], [9, 9], [10, 10]], columns=[["x", "x"], ["foo1", "foo2"]]
    )
    tm.assert_frame_equal(result, expected)

    # TODO: the result below is wrong, should be fixed (GH53325)
    result = df.agg({"x": foo1}, 0, 3, c=4)
    expected = pd.DataFrame([2, 3, 4], columns=["x"])
    tm.assert_frame_equal(result, expected)


def test_agg_std():
    df = pd.DataFrame(np.arange(6).reshape(3, 2), columns=["A", "B"])

    result = df.agg(np.std, ddof=1)
    expected = pd.Series({"A": 2.0, "B": 2.0}, dtype=float)
    tm.assert_series_equal(result, expected)

    result = df.agg([np.std], ddof=1)
    expected = pd.DataFrame({"A": 2.0, "B": 2.0}, index=["std"])
    tm.assert_frame_equal(result, expected)


def test_agg_np_size():
    # GH#42203, GH#48328
    df = pd.DataFrame([[1, 2, 3], [4, 5, 6], [7, 8, 9]], columns=["A", "B", "C"])

    result = df.agg({"A": [np.size]})
    expected = pd.DataFrame({"A": [3]}, index=["size"])
    tm.assert_frame_equal(result, expected)

    result = df.agg({"A": np.size})
    expected = pd.Series({"A": 3})
    tm.assert_series_equal(result, expected)

    result = df.agg({"A": [np.mean, np.size]})
    expected = pd.DataFrame({"A": [4.0, 3.0]}, index=["mean", "size"])
    tm.assert_frame_equal(result, expected)


def test_agg_list_like_series_method_not_reduction():
    # GH#65031 - the DataFrame-level reductions fast path must only fire for
    # genuine column-wise reductions. Series-returning DataFrame methods that
    # are not indexed by the columns (value_counts/duplicated/memory_usage)
    # must fall back to the per-column path rather than silently producing NaN
    # or wrong values.
    df = pd.DataFrame({"A": [1, 2, 3], "B": [4, 5, 6]})

    result = df.agg(["value_counts"])
    expected = pd.DataFrame(
        {
            ("A", "value_counts"): [1.0, 1.0, 1.0, np.nan, np.nan, np.nan],
            ("B", "value_counts"): [np.nan, np.nan, np.nan, 1.0, 1.0, 1.0],
        },
        index=[1, 2, 3, 4, 5, 6],
    )
    tm.assert_frame_equal(result, expected)

    result = df.agg(["duplicated"])
    expected = pd.DataFrame(
        {
            ("A", "duplicated"): [False, False, False],
            ("B", "duplicated"): [False, False, False],
        }
    )
    tm.assert_frame_equal(result, expected)

    # memory_usage is not a reduction; each column must match Series.memory_usage
    result = df.agg(["memory_usage"])
    for col in df.columns:
        assert result.loc["memory_usage", col] == df[col].memory_usage()

    # mixed dtypes previously raised ValueError on the fast path
    df_mixed = pd.DataFrame({"A": [1, 2, 3], "B": ["x", "yy", "zzz"]})
    result = df_mixed.agg(["memory_usage"])
    for col in df_mixed.columns:
        assert result.loc["memory_usage", col] == df_mixed[col].memory_usage()


def test_agg_list_like_square_frame_matching_labels():
    # GH#65031 a square frame with identical row/column labels must not let
    # a row-indexed result (DataFrame.duplicated) slip through the fast path
    df = pd.DataFrame([[0, 1], [0, 2]])
    result = df.agg(["duplicated"])
    expected = pd.DataFrame(
        {
            (0, "duplicated"): [False, True],
            (1, "duplicated"): [False, False],
        }
    )
    tm.assert_frame_equal(result, expected)


def test_agg_list_like_empty_frame_reduction():
    # GH#65031 empty frame with a list of reductions returns an empty frame
    # indexed by the func names (pandas 3.0 raised "No objects to concatenate")
    result = pd.DataFrame().agg(["sum"])
    expected = pd.DataFrame(index=["sum"])
    tm.assert_frame_equal(result, expected)


def test_agg_empty_list():
    # GH#39609
    df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
    result = df.agg([])
    expected = pd.DataFrame(index=pd.Index([]), columns=df.columns, dtype=object)
    tm.assert_frame_equal(result, expected)

    result = df.agg([], axis=1)
    expected = pd.DataFrame(index=df.index, columns=pd.Index([]))
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize("box", [np.array, pd.Index])
@pytest.mark.parametrize("func", [["sum", "min"], []])
def test_agg_array_like_func_names(box, func):
    # GH#69496 an ndarray or Index of names matches the list
    df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
    # np.array([]) would default to float64
    arg = box(func) if func else box(func, dtype=object)
    result = df.agg(arg)
    expected = df.agg(func)
    tm.assert_frame_equal(result, expected)


def test_agg_empty_dict():
    # GH#39609
    df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
    result = df.agg({})
    expected = pd.DataFrame(index=pd.Index([]), columns=df.columns[:0])
    tm.assert_frame_equal(result, expected)


@pytest.mark.parametrize(
    "dtype", ["uint64", "UInt64", "uint64[pyarrow]", "Sparse[uint64]"]
)
@pytest.mark.parametrize("funcs", [["max", "count"], ["max", "count", "mean"]])
@pytest.mark.parametrize("big", [True, False])
def test_agg_list_like_unsigned_and_signed_is_object(dtype, funcs, big):
    # GH#65031 max returns unsigned and count signed, and their common float
    # dtype rounds values above 2**53, so the result is object whatever the values
    if dtype == "uint64[pyarrow]":
        pytest.importorskip("pyarrow")
    value = 2**64 - 3 if big else 5
    df = pd.DataFrame(
        {"a": pd.Series([value, 1], dtype=dtype), "b": pd.Series([5, 1], dtype=dtype)}
    )

    result = df.agg(funcs)

    # asserted entry-wise because mean's own result is not under test
    assert (result.dtypes == object).all()
    assert result.loc["max", "a"] == value
    assert result.loc["count", "a"] == 2


@pytest.mark.parametrize("dtype", ["int64", "float64", "bool"])
@pytest.mark.parametrize("funcs", [["sum", "any"], ["max", "all", "sum"]])
def test_agg_list_like_bool_with_numeric_is_object(dtype, funcs):
    # GH#65031 bool results are not cast to numbers, as in Series.agg
    df = pd.DataFrame({"a": pd.Series([1, 1], dtype=dtype)})

    result = df.agg(funcs)

    tm.assert_series_equal(result["a"], df["a"].agg(funcs))
    assert result["a"].dtype == object
    assert result.loc[funcs[1], "a"] is True


@pytest.mark.parametrize("funcs", [["sum", "mean"], ["min", "max", "mean"]])
@pytest.mark.parametrize("values", [[10**17, 10**17 + 16], [10**17, 10**17 + 1]])
def test_agg_list_like_signed_int_and_float_is_float(funcs, values):
    # GH#65031 int64 with float64 stays float64 as in Series.agg, whatever the
    # values
    df = pd.DataFrame({"a": values})

    result = df.agg(funcs)

    tm.assert_series_equal(result["a"], df["a"].agg(funcs))
    assert result["a"].dtype == np.float64


def test_agg_list_like_unsigned_and_signed_common_int():
    # GH#65031 uint32 and int64 have a common integer dtype, so nothing is lost
    df = pd.DataFrame({"a": pd.Series([5, 1], dtype="uint32")})

    result = df.agg(["max", "count"])

    expected = pd.DataFrame({"a": [5, 2]}, index=["max", "count"])
    tm.assert_frame_equal(result, expected)


def test_agg_list_like_axis_1_not_cast_to_float():
    # GH#65031 axis=1 reduces the transpose, so the object fallback applies there
    # too
    big = 2**64 - 3
    df = pd.DataFrame({"a": pd.Series([big, 5], dtype="uint64")})

    result = df.agg(["max", "count"], axis=1)

    # the dtype assert is what fires: a rounded np.float64 still compares equal to
    # big, because numpy widens the int rather than comparing it exactly
    assert result["max"].dtype == object
    assert result.loc[0, "max"] == big


def test_agg_dist_like_and_nonunique_columns():
    # GH#51099
    df = pd.DataFrame(
        {"A": [None, 2, 3], "B": [1.0, np.nan, 3.0], "C": ["foo", None, "bar"]}
    )
    df.columns = ["A", "A", "C"]

    result = df.agg({"A": "count"})
    expected = df["A"].count()
    tm.assert_series_equal(result, expected)


@pytest.mark.parametrize("engine_name", ["unknown", 25])
def test_wrong_engine(engine_name):
    with pytest.raises(ValueError, match="Unknown engine "):
        pd.DataFrame().apply(lambda x: x, engine=engine_name)


def test_apply_timedelta_preserves_resolution():
    # GH#52411 - UDFs via apply should preserve datetime resolution
    # rather than always returning nanoseconds
    df = pd.DataFrame(
        {
            "a": pd.Series(["2023-01-01", "2023-01-02"], dtype="datetime64[s]"),
            "b": pd.Series(["2023-01-02", "2023-01-03"], dtype="datetime64[s]"),
        }
    )
    direct = df["a"] - df["b"]
    applied = df.apply(lambda row: row["a"] - row["b"], axis=1)
    assert applied.dtype == direct.dtype


def test_agg_dict_func_returning_series_not_transposed():
    # GH#19756 agg with a dict whose function returns a Series must not be
    #  transposed relative to a function returning the equivalent values
    df = pd.DataFrame([1, 2], columns=["a"])
    result = df.agg({"a": lambda x: pd.Series([1, 3], name="a")})
    expected = df.agg({"a": lambda x: x.cumsum()})
    tm.assert_frame_equal(result, expected)
    tm.assert_frame_equal(result, pd.DataFrame({"a": [1, 3]}))

    # a function returning a scalar constant must likewise agree with an
    # equivalent reduction (it used to broadcast to a transposed DataFrame)
    tm.assert_series_equal(df.agg({"a": lambda x: 3}), df.agg({"a": lambda x: x.sum()}))


def test_agg_list_of_funcs_on_object_columns():
    # GH#31298 a list of functions can be applied to object/string columns,
    # just like numeric columns
    df = pd.DataFrame(
        {
            "col_3": ["cat", "dog", "dog", "cat", "cat"],
            "col_4": ["feline", "canine", "canine", "feline", "feline"],
        }
    )
    result = df.agg([lambda x: len(x), lambda x: x.isnull().sum()])
    expected = pd.DataFrame(
        [[5, 5], [0, 0]],
        index=["<lambda>", "<lambda>"],
        columns=["col_3", "col_4"],
    )
    tm.assert_frame_equal(result, expected)

    # a bare builtin (len) mixed with a lambda -- the form a commenter flagged
    result_builtin = df.agg([len, lambda x: x.isnull().sum()])
    expected_builtin = pd.DataFrame(
        [[5, 5], [0, 0]],
        index=["len", "<lambda>"],
        columns=["col_3", "col_4"],
    )
    tm.assert_frame_equal(result_builtin, expected_builtin)


def test_agg_list_mixing_string_and_custom_named_func():
    # GH#31851 a list mixing a string alias and a custom function whose
    # __name__ was overridden must not raise
    df = pd.DataFrame({"A": [1, 2, 3, 4, 5, np.nan], "B": [1, 2, 3, 4, 5, 7.0]})

    def perc_fun(q):
        def func(arr):
            return np.nanpercentile(arr, q)

        func.__name__ = f"p-{q}"
        return func

    result = df.agg(["mean", perc_fun(10)])
    expected = pd.DataFrame(
        {"A": [3.0, 1.4], "B": [3.6666666666666665, 1.5]},
        index=["mean", "p-10"],
    )
    tm.assert_frame_equal(result, expected)


def test_named_agg_with_lambda():
    # GH#41768 named aggregation mixing builtins/strings with a lambda must not
    # crash
    df = pd.DataFrame(
        [[1, 2, 3], [4, 5, 6], [7, 8, 9], [np.nan, np.nan, np.nan]],
        columns=["A", "B", "C"],
    )
    result = df.agg(x=("A", max), y=("B", "min"), z=("C", lambda s: np.mean(s)))
    expected = pd.DataFrame(
        {
            "A": [7.0, np.nan, np.nan],
            "B": [np.nan, 2.0, np.nan],
            "C": [np.nan, np.nan, 6.0],
        },
        index=["x", "y", "z"],
    )
    tm.assert_frame_equal(result, expected)

    # the plain dict-of-funcs form with a lambda (the sibling raised in the
    # discussion) must also work
    result_dict = df.agg({"A": max, "B": "min", "C": lambda s: np.mean(s)})
    expected_dict = pd.Series([7.0, 2.0, 6.0], index=["A", "B", "C"])
    tm.assert_series_equal(result_dict, expected_dict)


def test_agg_dict_string_funcs_with_duplicate_columns():
    # GH#43748 aggregating with a dict of (non-list) string funcs must not
    # crash when the selected labels are duplicated in the columns
    df = pd.DataFrame([[1, 2, 3, 4], [5, 6, 7, 8]], columns=["a", "a", "b", "b"])
    result = df.agg({"a": "sum", "b": "min"})
    expected = pd.Series([6, 8, 3, 4], index=["a", "a", "b", "b"])
    tm.assert_series_equal(result, expected)


def test_apply_expand_single_row_preserves_dict_order():
    # GH#45783 apply(result_type="expand") on a single-row frame must preserve
    # the dict key order returned by the callable instead of sorting columns
    def func(row):
        return {"Z": str(row["C1"]), "Y": "", "C2": "GCT", "C1": ""}

    df = pd.DataFrame(np.arange(4).reshape(1, 4), columns=["C4", "C3", "C2", "C1"])
    result = df.apply(func, axis=1, result_type="expand")
    assert result.columns.tolist() == ["Z", "Y", "C2", "C1"]
